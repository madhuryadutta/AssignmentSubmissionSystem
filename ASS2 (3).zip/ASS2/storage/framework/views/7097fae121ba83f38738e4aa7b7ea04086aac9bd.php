<!doctype html>
<html lang="en">
  <head>
    <title>Create Group</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <form action="<?php echo e(url('/')); ?>/teacher/creategroup" method="POST">
        <?php echo csrf_field(); ?>
    <div class="container">
        <h1 class="text-center">Create Group</h1>
<div class="form-group">
  <label for="">Class Name</label>
  <input type="text" name="c_name" id="" class="form-control" placeholder="" aria-describedby="helpId">
  
</div>
<div class="form-group">
    <label for="">Department</label>
    <input type="text" name="department" id="" class="form-control" placeholder="" aria-describedby="helpId">
    
  </div>
  <div class="form-group">
    <label for="">Semester</label>
    <input type="text" name="semester" id="" class="form-control" placeholder="" aria-describedby="helpId">
    
  </div>
  <button class="btn btn-primary">
     Submit
  </button>
    </div>
</form>
   
  </body>
</html><?php /**PATH E:\Laravel\ASS2\resources\views/create_group.blade.php ENDPATH**/ ?>