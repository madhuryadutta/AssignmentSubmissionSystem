<!DOCTYPE html>



<head>
	<meta charset="UTF-8">
	<!-- bootstrap5 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
	<!-- bootstrap4 -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	<title>Log_in_Page</title>
</head>

<script src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('asset/css/studentlogin.css')); ?>">

<body class="body">
		<?php if(session('mail')): ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e(session('mail')); ?>

		</div>
		<?php endif; ?>
		<?php if(session('pass')): ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e(session('pass')); ?>

		</div>
		<?php endif; ?>
		<?php if(session('status')): ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e(session('status')); ?>

		</div>
		<?php elseif(!session('status')): ?>
		<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e($message); ?>

		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e($message); ?>

		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<?php $__errorArgs = ['rollno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e($message); ?>

		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e($message); ?>

		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<?php $__errorArgs = ['confirmpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<div class="alert alert-success alert-dismissible">
		<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
		<?php echo e($message); ?>

		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		<?php endif; ?>
	</div>
	</div>

	<div id="formWrapper">
		<div id="form">

			<form class="signup-form" method="POST" action="<?php echo e(url('login')); ?>">
				<?php echo e(csrf_field()); ?>

				<center>
					<div class="mt-3 mb-3">
						<img src="<?php echo e(asset('asset/img/logo.jpg')); ?>" alt="Log-In Here" width="100" height="100">
					</div>
				</center>
				<div class="form-item">
					<p class="formLabel">Email</p>
					<input type="email" name="Email" id="email" class="form-style" autocomplete="off" value="<?php echo e(old('Email')); ?>" />
					<span class="text-danger"><?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<?php echo e($message); ?>

						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
				</div>
				<div class="form-item">
					<p class="formLabel">Password</p>
					<input type="password" name="Password" id="password" class="form-style" />
					<span class="text-danger"><?php $__errorArgs = ['Password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<?php echo e($message); ?>

						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
					<!-- <p><a href="#"><small>Forgot Password ?</small></a></p> -->
				</div>
				<div class="form-item">
					<p class="pull-left" data-toggle="modal" data-target=".bd-example-modal-lg"><a href="#"><small> Register</small></a></p>
					<input type="submit" class="login pull-right" value="Log In">
					<div class="clear-fix"></div>
				</div>
			</form>
		</div>
	</div>


	<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content bg-light text-dark">
				<div class="container-fluid">
					<center>
						<div class="mb-3 mt-3">
							<h3 class="blurb" style="color:#58bff6">Lets Create An Account </h3>
						</div>
					</center>


					<form class="signup-form" method="POST" action="<?php echo e(url('studentreg')); ?>">
						<?php echo e(csrf_field()); ?>

						<div class="col">
							<div class="row">
								<label for="signup-name" class="col-sm-4">Full Name</label>
								<input id="signup-name" class="col-sm-4 ml-5" type="text" name="name" value="<?php echo e(old('name')); ?>" />
							</div>

							<div class="row mt-2">
								<label for="signup-email" class="col-sm-4">Email Address</label>
								<input id="signup-email" class="col-sm-4 ml-5" type="email" name="email" autocomplete="off" value="<?php echo e(old('email')); ?>" />
							</div>
							<div class="row mt-2">
								<label for="address" class="col-sm-4">Address</label>
								<textarea id="address" class="col-sm-4 ml-5" type="text" name="address"></textarea>
							</div>

							<div class="row mt-2">
								<label for="Select semester" class="col-sm-4">Select Semester</label>
								<select class="col-sm-4 ml-5" name="class">
									<option value="1" selected>1st</option>
									<option value="2">2nd</option>
									<option value="3">3rd</option>
									<option value="4">4th</option>
									<option value="5">5th</option>
									<option value="6">6th</option>
								</select>
							</div>

							<div class="row mt-2">
								<label for="Select department" class="col-sm-4">Select Department</label>
								<select class="col-sm-4 ml-5" name="department">
									<?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($c->d_id); ?>"><?php echo e($c->d_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="row mt-2">
								<label for="roll-no" class="col-sm-4">Roll-No</label>
								<input id="roll-no" type="number" name="rollno" placeholder="Enter Your Class Roll-No" class="col-sm-4 ml-5" value="<?php echo e(old('rollno')); ?>" />
							</div>
							<div class="row mt-2">
								<label for="Date Of Birth" class="col-sm-4">Date Of Birth</label>
								<input id="dob" type="date" name="dob" class="col-sm-4 ml-5" value="<?php echo e(old('dob')); ?>" />
							</div>
							<div class="row mt-2">
								<label for="Select department" class="col-sm-4">Gender</label>
								<div class="col-sm-6 ml-5">
									<input type="radio" id="male" name="gender" value="M">
									 <label for="male">MALE </label>
									<input type="radio" id="female" name="gender" value="F">
									 <label for="female">FEMALE </label>
									<input type="radio" id="others" name="gender" value="O">
									 <label for="others">OTHERS</label>
								</div>

							</div>
							<div class="row mt-2">
								<label for="signup-pw" class="col-sm-4">Password</label>
								<input id="signup-pw" type="password" name="password" autocomplete="off" class="col-sm-4 ml-5" />
							</div>
							<div class="row mt-2">
								<label for="signup-cpw" class="col-sm-4">Confirm Password</label>
								<input id="signup-cpw" type="password" name="confirmpassword" autocomplete="off" class="col-sm-4 ml-5" />
							</div>

							<div class="mt-2 mb-3">
								<center>
									<button class="btn btn-secondary btn-sm">signup</button>
								</center>
							</div>


						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</div>
	<script src="<?php echo e(asset('asset/js/studentlogin.js')); ?>"></script>
</body>

</html><?php /**PATH E:\Laravel\ASS2\resources\views/studentlogin.blade.php ENDPATH**/ ?>