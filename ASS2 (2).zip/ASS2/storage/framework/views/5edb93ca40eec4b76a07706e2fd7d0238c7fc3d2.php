<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OBJECTIVE</title>
</head>
<body>
<h1>OBJECTIVE:</h1>
<br>
<h2>1.Teacher Module:</h2>
<br>
a)Teacher can create class-room.
<br>
b)Teacher can approve student's request to join the class room.
<br>
c)Teacher can add assignments. 
<br>
d)Teacher can grade assignments.
<br>
e)Teacher can set submission time limit(Last Date).
<br>
f)Teacher can view Submission Status(Submitted/ Unsubmitted /Late Submission).
<br>
<h2>2.Student Module:</h2>
<br>
a)Students can create account in the system.
<br>
b)Students can see pending assignments.
<br>
c)Students can submit assignment.
<br>
d)Student can see their grades.

</body>
</html><?php /**PATH E:\Laravel\ASS2\resources\views/obj.blade.php ENDPATH**/ ?>